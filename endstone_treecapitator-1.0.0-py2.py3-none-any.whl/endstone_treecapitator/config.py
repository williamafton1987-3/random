require_sneaking = True
max_tree_blocks = 128