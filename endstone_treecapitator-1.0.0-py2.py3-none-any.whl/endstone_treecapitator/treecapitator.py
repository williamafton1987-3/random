from random import randint
from endstone.inventory import ItemStack
from endstone.level import Location
from endstone.plugin import Plugin
from endstone.event import *
from endstone_treecapitator import config

tree_blocks = [
    "minecraft:oak_log",
    "minecraft:oak_wood",
    "minecraft:birch_log",
    "minecraft:birch_wood",
    "minecraft:spruce_log",
    "minecraft:spruce_wood",
    "minecraft:acacia_log",
    "minecraft:acacia_wood",
    "minecraft:poplar_log",
    "minecraft:poplar_wood",
    "minecraft:dark_oak_log",
    "minecraft:dark_oak_wood",
    "minecraft:pale_oak_log",
    "minecraft:pale_oak_wood",
    "minecraft:jungle_log",
    "minecraft:jungle_wood",
    "minecraft:cherry_log",
    "minecraft:cherry_wood",
    "minecraft:mangrove_log",
    "minecraft:mangrove_wood",
]

axes = [
    "minecraft:wooden_axe",
    "minecraft:stone_axe",
    "minecraft:gold_axe",
    "minecraft:iron_axe",
    "minecraft:diamond_axe",
    "minecraft:netherite_axe",
]


class Treecapitator(Plugin):
    api_version = "0.11"

    def on_load(self) -> None:
        self.logger.info(f"loaded blocks: {", ".join(tree_blocks)}")

    def on_enable(self) -> None:
        self.register_events(self)

    @event_handler
    def on_block_break(self, event: BlockBreakEvent):
        block = event.block
        player = event.player
        
        player_item = player.inventory.item_in_main_hand

        if player_item.type not in axes: return
        if config.require_sneaking and not player.is_sneaking: return
        

        if block.type in tree_blocks:
            for i in range(config.max_tree_blocks):
                above_block = block.get_relative(0, 1, 0)
                block_type = above_block.type
                if block_type in tree_blocks:
                    self.break_block(above_block.location)
                    block = above_block

                else:
                    break

    def break_block(self, location: Location):
        # self.logger.info(f"block at {(location.x, location.y, location.z)}")
        block = location.block
        block_type = block.type
        
        block.set_type("minecraft:air")
        item_stack = ItemStack(block_type, amount=1)
        location.dimension.drop_item(block.location, item_stack)