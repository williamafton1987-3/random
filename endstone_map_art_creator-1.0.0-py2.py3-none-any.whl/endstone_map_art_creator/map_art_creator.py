from endstone.plugin import Plugin
from endstone import Player
from endstone.event import *
from endstone.command import *
from endstone.map import *
from endstone.inventory import *

from numpy import ndarray, uint8
from PIL import Image
import requests
import io
import numpy

class ImageMapRenderer(MapRenderer):
    def __init__(self, image_array: str):
        super().__init__()
        self.image_array = image_array

    def render(self, view: MapView, canvas: MapCanvas, player: Player):
        canvas.draw_image(0, 0, self.image_array)

class MapArtCreator(Plugin):
    api_version = "0.11"

    commands = {
        "mapart": {
            "description": "Create Map art from an image",
            "usages": ["/mapart <link: string>"]
        }
    }

    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        match command.name:
            case "mapart":
                link = args[0]
                image_array = self.get_image_array_from_link(link)
                server = sender.server
                player = server.get_player(sender.name)

                map_view = server.create_map(player.dimension)
                map_view.scale = MapView.FARTHEST
                map_view.add_renderer(ImageMapRenderer(image_array))
                map_view.locked = True

                item_stack = ItemStack("minecraft:filled_map")
                meta = item_stack.item_meta
                meta.map_view = map_view
                
                item_stack.set_item_meta(meta)


                player.inventory.add_item(item_stack)
                sender.send_message(f"Created map")

        return True




    def get_image_array_from_link(self, link: str):
        response = requests.get(link)
        bytes = response.content

        image = Image.open(io.BytesIO(bytes))\
            .convert("RGBA")\
            .resize((128, 128))

        image_array = numpy.array(image, dtype=uint8)
        return image_array

